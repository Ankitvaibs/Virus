# jquery.promise

Promise implementation using jQuery.
