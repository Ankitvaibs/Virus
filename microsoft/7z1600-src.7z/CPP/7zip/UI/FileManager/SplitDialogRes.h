#define IDD_SPLIT  7300

#define IDT_SPLIT_PATH    7301
#define IDT_SPLIT_VOLUME  7302

#define IDC_SPLIT_PATH     100
#define IDB_SPLIT_PATH     101
#define IDC_SPLIT_VOLUME   102
